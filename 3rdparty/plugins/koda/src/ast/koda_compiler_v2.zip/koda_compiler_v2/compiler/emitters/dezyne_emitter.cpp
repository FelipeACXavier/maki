#include "dezyne_emitter.h"

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <format>
#include <fstream>

#include "koda_compiler.h"

namespace koda
{
namespace
{
std::uint32_t increment(std::map<SymbolId, std::uint32_t>& values, SymbolId key)
{
  return ++values[key];
}
}

VoidResult DezyneEmitter::emit(const ir::Program& program,
                               const SymbolRegistry& symbols,
                               const CompilerOptions& options)
{
  mSymbols = &symbols;
  mOptions = &options;
  mGeneratedFiles.clear();
  mCapabilityTriggerCounts.clear();
  mTriggerEvents.clear();
  mFlowResults.clear();
  mModel.symbols.clear();

  std::filesystem::create_directories(options.outputDir);

  auto counted = precomputeTriggerCounts(program);
  if (!counted.IsSuccess()) return counted;

  // Capabilities first: task flow connections know exactly which ports these expose.
  for (const auto& component : program.components)
  {
    if (component.kind != ir::ComponentKind::Capability) continue;
    auto result = emitCapability(component);
    if (!result.IsSuccess()) return result;
  }

  for (const auto& component : program.components)
  {
    if (component.kind != ir::ComponentKind::Task) continue;
    auto result = emitTask(component);
    if (!result.IsSuccess()) return result;
  }

  return VoidResult{};
}

VoidResult DezyneEmitter::precomputeTriggerCounts(const ir::Program& program)
{
  for (const auto& component : program.components)
    for (const auto& flow : component.flows)
      countStrategyTriggers(flow.strategy);
  return VoidResult{};
}

void DezyneEmitter::countStrategyTriggers(const ir::PStrategy& strategy)
{
  if (!strategy) return;
  if (auto p = std::get_if<ir::Strategy::Sequence>(&strategy->value)) for (const auto& x : p->items) countStrategyTriggers(x);
  else if (auto p = std::get_if<ir::Strategy::Join>(&strategy->value)) for (const auto& x : p->items) countStrategyTriggers(x);
  else if (auto p = std::get_if<ir::Strategy::Either>(&strategy->value)) for (const auto& x : p->items) countStrategyTriggers(x);
  else if (auto p = std::get_if<ir::Strategy::Let>(&strategy->value)) countCallTrigger(p->call);
  else if (auto p = std::get_if<ir::Strategy::Within>(&strategy->value))
  {
    countStrategyTriggers(p->body); countStrategyTriggers(p->fallback);
    for (const auto& h : p->handlers) countHandlerTriggers(h);
  }
  else if (auto p = std::get_if<ir::Strategy::IfElse>(&strategy->value))
  {
    countStrategyTriggers(p->thenBranch); countStrategyTriggers(p->elseBranch);
  }
  else if (auto p = std::get_if<ir::Strategy::Repeat>(&strategy->value))
  {
    countStrategyTriggers(p->body); for (const auto& h : p->handlers) countHandlerTriggers(h);
  }
  else if (auto p = std::get_if<ir::Strategy::TaskCall>(&strategy->value))
  {
    countCallTrigger(p->call); for (const auto& h : p->handlers) countHandlerTriggers(h);
  }
}

void DezyneEmitter::countHandlerTriggers(const ir::PHandler& handler)
{
  if (!handler) return;
  if (handler->emitter) countCallTrigger(*handler->emitter);
  countStrategyTriggers(handler->body);
}

void DezyneEmitter::countCallTrigger(const ir::Call& call)
{
  if (call.kind == ir::CallKind::CapabilityTrigger)
    ++mCapabilityTriggerCounts[call.target];
}

VoidResult DezyneEmitter::emitCapability(const ir::Component& capability)
{
  if (mOptions->dryRun) return VoidResult{};

  const auto filename = std::format("{}/a_{}.dzn", mOptions->outputDir, toFilename(capability.name));
  std::ofstream file(filename);
  if (!file.is_open()) return VoidResult::Failed("Failed to open: " + filename);

  const auto componentId = recordComponent(componentName(capability.name), filename, capability.symbol, capability.span);

  file << "import iaction.dzn;\n";
  file << "import isignal.dzn;\n\n";
  file << std::format("component {} {{\n", componentName(capability.name));

  for (const auto& event : capability.events)
  {
    if (event.kind == ir::EventKind::Trigger)
    {
      mTriggerEvents[capability.symbol] = event.name;
      // Trigger usage is counted by capability symbol, not event symbol.
      const auto actualCount = std::max<std::uint32_t>(1, mCapabilityTriggerCounts[capability.symbol]);
      for (std::uint32_t i = 0; i < actualCount; ++i)
      {
        const auto port = actualCount == 1 ? event.name : std::format("{}_{}", event.name, i + 1);
        file << std::format("  provides iaction {};\n", port);
        recordPort(componentId, port, filename, event.symbol, event.span);
      }
    }
    else if (event.kind == ir::EventKind::Abort || event.kind == ir::EventKind::In)
    {
      file << std::format("  provides iaction {};\n", event.name);
      recordPort(componentId, event.name, filename, event.symbol, event.span);
    }
    else if (event.kind == ir::EventKind::Out)
    {
      file << std::format("  provides isignal {};\n", event.name);
      recordPort(componentId, event.name, filename, event.symbol, event.span);
    }
  }

  file << "}\n";
  file.close();
  mGeneratedFiles.push_back(filename);
  return VoidResult{};
}

VoidResult DezyneEmitter::emitTask(const ir::Component& task)
{
  mFlowResults.clear();
  for (const auto& flow : task.flows)
  {
    auto result = emitFlow(task, flow);
    if (!result.IsSuccess()) return VoidResult::Failed(result.ErrorMessage());
    mFlowResults[flow.symbol] = result.Value();
  }

  if (mOptions->dryRun) return VoidResult{};

  const auto filename = std::format("{}/{}_task.dzn", mOptions->outputDir, toFilename(task.name));
  std::ofstream file(filename);
  if (!file.is_open()) return VoidResult::Failed("Failed to open: " + filename);

  const auto componentId = recordComponent(componentName(task.name), filename, task.symbol, task.span);

  file << "import iaction.dzn;\n";
  file << "import isignal.dzn;\n";

  std::set<SymbolId> capabilityTypes;
  for (const auto& arg : task.arguments)
    if (arg.type.kind == TypeKind::Component && arg.type.symbol != InvalidSymbol)
      capabilityTypes.insert(arg.type.symbol);
  for (const auto cap : capabilityTypes)
    file << std::format("import a_{}.dzn;\n", toFilename(symbolName(cap)));
  for (const auto& flow : task.flows)
    file << std::format("import {}.dzn;\n", toFilename(flow.name));

  bool hasAlarm = false;
  for (const auto& [_, result] : mFlowResults) hasAlarm = hasAlarm || !result.alarms.empty();
  if (hasAlarm) file << "import alarm.dzn;\n";
  file << "\n";

  file << std::format("component {} {{\n", componentName(task.name));
  file << "  provides iaction api;\n\n";
  recordPort(componentId, "api", filename, task.symbol, task.span);
  file << "  system {\n";

  for (const auto& arg : task.arguments)
  {
    if (arg.type.kind != TypeKind::Component || arg.type.symbol == InvalidSymbol) continue;
    file << std::format("    {} {};\n", componentName(symbolName(arg.type.symbol)), arg.name);
    recordInstance(componentId, arg.name, filename, arg.symbol, arg.span);
  }
  for (const auto& flow : task.flows)
  {
    file << std::format("    {} {};\n", flowName(flow.name), "f_" + toFilename(flow.name));
    recordInstance(componentId, "f_" + toFilename(flow.name), filename, flow.symbol, flow.span);
  }
  for (const auto& [flowId, result] : mFlowResults)
  {
    for (const auto& alarm : result.alarms)
    {
      file << std::format("    calarm {};\n", alarm);
      recordInstance(componentId, alarm, filename, flowId, mSymbols->get(flowId) ? std::optional<Span>{mSymbols->get(flowId)->span} : std::nullopt);
    }
  }

  file << "\n";
  std::vector<Connection> connections;
  if (!task.flows.empty())
  {
    const auto mainIt = std::find_if(task.flows.begin(), task.flows.end(), [](const ir::Flow& f) { return f.name == "main"; });
    const auto& entry = mainIt != task.flows.end() ? *mainIt : task.flows.front();
    connections.push_back({"api", "", "f_" + toFilename(entry.name), "api", entry.span});
  }

  for (const auto& flow : task.flows)
  {
    const auto instance = "f_" + toFilename(flow.name);
    const auto resultIt = mFlowResults.find(flow.symbol);
    if (resultIt == mFlowResults.end()) continue;
    for (const auto& use : resultIt->second.calls)
    {
      if (use.kind == CallUse::Kind::Flow)
      {
        connections.push_back({instance, use.localPort, "f_" + toFilename(symbolName(use.target)), "api", use.span});
        continue;
      }

      const auto receiverName = symbolName(use.receiver);
      auto targetPort = eventName(use.target);
      if (use.kind == CallUse::Kind::Trigger)
      {
        const auto total = mCapabilityTriggerCounts[use.target];
        // use.target is capability symbol for trigger calls.
        targetPort = triggerEventName(use.target);
        if (std::max<std::uint32_t>(1, total) > 1)
          targetPort = std::format("{}_{}", targetPort, use.ordinal);
      }
      connections.push_back({instance, use.localPort, receiverName, targetPort, use.span});
    }
    for (const auto& alarm : resultIt->second.alarms)
      connections.push_back({instance, alarm, alarm, "api", flow.span});
  }

  // Dezyne action resources cannot have multiple clients directly. Insert action arbiters
  // at the task-composition level when several generated flow ports target the same port.
  std::map<std::string, std::vector<std::size_t>> byTarget;
  for (std::size_t i = 0; i < connections.size(); ++i)
  {
    if (connections[i].lhsInstance == "api") continue;
    byTarget[connections[i].rhsInstance + "." + connections[i].rhsPort].push_back(i);
  }

  std::uint32_t arbiterId = 0;
  for (const auto& [_, indices] : byTarget)
  {
    if (indices.size() < 2) continue;
    auto helper = createActionArbiterComponent(static_cast<std::uint32_t>(indices.size()));
    if (!helper.IsSuccess()) return helper;
    const auto arbiter = std::format("arbiter{}_{}", indices.size(), arbiterId++);
    file << std::format("    caction_arbiter{} {};\n", indices.size(), arbiter);
    recordInstance(componentId, arbiter, filename, std::nullopt, std::nullopt);

    const auto originalRhsInstance = connections[indices.front()].rhsInstance;
    const auto originalRhsPort = connections[indices.front()].rhsPort;
    for (std::size_t client = 0; client < indices.size(); ++client)
    {
      auto& c = connections[indices[client]];
      c.rhsInstance = arbiter;
      c.rhsPort = std::format("client{}", client);
    }
    connections.push_back({arbiter, "resource", originalRhsInstance, originalRhsPort, connections[indices.front()].span});
  }

  file << "\n";
  for (const auto& c : connections)
  {
    if (c.lhsInstance == "api")
      file << std::format("    api <=> {}.{};\n", c.rhsInstance, c.rhsPort);
    else
      file << std::format("    {}.{} <=> {}.{};\n", c.lhsInstance, c.lhsPort, c.rhsInstance, c.rhsPort);
    recordConnection(componentId, c, filename);
  }
  file << "  }\n";
  file << "}\n";

  file.close();
  mGeneratedFiles.push_back(filename);
  return VoidResult{};
}

Result<DezyneEmitter::FlowResult> DezyneEmitter::emitFlow(const ir::Component& task, const ir::Flow& flow)
{
  FlowContext env;
  const auto filename = std::format("{}/{}.dzn", mOptions->outputDir, toFilename(flow.name));
  auto endpoint = emitStrategy(flow.strategy, env, filename);
  if (!endpoint.IsSuccess()) return Result<FlowResult>::Failed(endpoint.ErrorMessage());

  env.core.push_front(std::format("api <=> {}", endpoint.Value()));
  env.includes.insert("iaction.dzn");

  if (!mOptions->dryRun)
  {
    std::ofstream file(filename);
    if (!file.is_open()) return Result<FlowResult>::Failed("Failed to open: " + filename);
    const auto componentId = recordComponent(flowName(flow.name), filename, flow.symbol, flow.span);

    for (const auto& include : env.includes) file << "import " << include << ";\n";
    file << "\n";
    file << std::format("component {} {{\n", flowName(flow.name));
    file << "  provides iaction api;\n";
    recordPort(componentId, "api", filename, flow.symbol, flow.span);
    for (const auto& port : env.requiresPorts)
    {
      file << "  requires " << port << ";\n";
      const auto space = port.find_last_of(' ');
      const auto name = space == std::string::npos ? port : port.substr(space + 1);
      auto use = std::find_if(env.calls.begin(), env.calls.end(), [&](const CallUse& c) { return c.localPort == name; });
      if (use != env.calls.end())
        recordPort(componentId, name, filename, use->target != InvalidSymbol ? std::optional<SymbolId>{use->target} : std::nullopt, use->span);
      else
        recordPort(componentId, name, filename, flow.symbol, flow.span);
    }
    file << "\n  system {\n";
    for (const auto& def : env.definitions)
    {
      file << "    " << def.text << ";\n";
      recordInstance(componentId, def.instance, filename, flow.symbol, def.span);
    }
    file << "\n";
    for (const auto& line : env.core) file << "    " << line << ";\n";
    file << "  }\n}\n";
    file.close();
    mGeneratedFiles.push_back(filename);
  }

  return FlowResult{endpoint.Value(), env.calls, env.alarms};
}

Result<std::string> DezyneEmitter::emitStrategy(const ir::PStrategy& strategy, FlowContext& env, const std::string& flowFile)
{
  if (!strategy) return Result<std::string>::Failed("Invalid strategy");

  if (auto p = std::get_if<ir::Strategy::Sequence>(&strategy->value))
  {
    std::vector<ir::PStrategy> items;
    for (const auto& item : p->items)
      if (!std::holds_alternative<ir::Strategy::Continue>(item->value)) items.push_back(item);
    if (items.empty()) return std::string("continue");
    if (items.size() == 1) return emitStrategy(items.front(), env, flowFile);

    auto helper = createSequenceComponent(static_cast<std::uint32_t>(items.size()));
    if (!helper.IsSuccess()) return Result<std::string>::Failed(helper.ErrorMessage());
    const auto id = env.sequence++;
    env.includes.insert(std::format("sequence{}.dzn", items.size()));
    env.definitions.push_back({std::format("csequence{} s{}", items.size(), id), std::format("s{}", id), strategy->span});
    for (std::size_t i = 0; i < items.size(); ++i)
    {
      auto child = emitStrategy(items[i], env, flowFile); if (!child.IsSuccess()) return child;
      env.core.push_back(std::format("s{}.action{} <=> {}", id, i, child.Value()));
    }
    return std::format("s{}.api", id);
  }
  if (auto p = std::get_if<ir::Strategy::Join>(&strategy->value))
  {
    const auto id = env.join++;
    env.includes.insert("parallel.dzn");
    env.definitions.push_back({std::format("cparallel p{}", id), std::format("p{}", id), strategy->span});
    for (std::size_t i = 0; i < p->items.size(); ++i)
    {
      auto child = emitStrategy(p->items[i], env, flowFile); if (!child.IsSuccess()) return child;
      env.core.push_back(std::format("p{}.action{} <=> {}", id, i, child.Value()));
    }
    return std::format("p{}.api", id);
  }
  if (std::holds_alternative<ir::Strategy::Either>(strategy->value))
    return Result<std::string>::Failed(std::format("Dezyne emitter: 'either' is not implemented at {}", strategy->span.toString()));
  if (std::holds_alternative<ir::Strategy::Let>(strategy->value))
    return Result<std::string>::Failed(std::format("Dezyne emitter: 'let' is not implemented at {}", strategy->span.toString()));
  if (auto p = std::get_if<ir::Strategy::Within>(&strategy->value))
  {
    auto body = emitStrategy(p->body, env, flowFile); if (!body.IsSuccess()) return body;
    auto fallback = emitStrategy(p->fallback, env, flowFile); if (!fallback.IsSuccess()) return fallback;
    const auto id = env.within++;
    const auto alarm = std::format("alarm{}", env.alarm++);
    env.includes.insert("within.dzn"); env.includes.insert("ialarm.dzn");
    env.definitions.push_back({std::format("cwithin w{}", id), std::format("w{}", id), strategy->span});
    env.requiresPorts.insert(std::format("ialarm {}", alarm));
    env.alarms.push_back(alarm);
    env.core.push_back(std::format("w{}.action1 <=> {}", id, body.Value()));
    env.core.push_back(std::format("w{}.action2 <=> {}", id, fallback.Value()));
    env.core.push_back(std::format("w{}.alarm <=> {}", id, alarm));
    return std::format("w{}.api", id);
  }
  if (std::holds_alternative<ir::Strategy::IfElse>(strategy->value))
    return Result<std::string>::Failed(std::format("Dezyne emitter: 'if/else' is not implemented at {}", strategy->span.toString()));
  if (auto p = std::get_if<ir::Strategy::Repeat>(&strategy->value))
  {
    auto body = emitStrategy(p->body, env, flowFile); if (!body.IsSuccess()) return body;
    std::string endpoint = body.Value();
    for (const auto& handler : p->handlers)
    {
      env.previousCall = endpoint;
      auto wrapped = emitHandler(handler, env, flowFile); if (!wrapped.IsSuccess()) return wrapped;
      endpoint = wrapped.Value();
    }

    if (p->iterations > 0)
    {
      const auto id = env.every++;
      const auto alarm = std::format("alarm{}", env.alarm++);
      env.includes.insert("every.dzn"); env.includes.insert("ialarm.dzn");
      env.definitions.push_back({std::format("cevery e{}", id), std::format("e{}", id), strategy->span});
      env.requiresPorts.insert(std::format("ialarm {}", alarm));
      env.alarms.push_back(alarm);
      env.core.push_back(std::format("e{}.action1 <=> {}", id, endpoint));
      env.core.push_back(std::format("e{}.alarm <=> {}", id, alarm));
      return std::format("e{}.api", id);
    }

    const auto id = env.repeat++;
    env.includes.insert("repeat.dzn");
    env.definitions.push_back({std::format("crepeat r{}", id), std::format("r{}", id), strategy->span});
    env.core.push_back(std::format("r{}.action1 <=> {}", id, endpoint));
    return std::format("r{}.api", id);
  }
  if (std::holds_alternative<ir::Strategy::Guard>(strategy->value))
    return Result<std::string>::Failed(std::format("Dezyne emitter: 'guard' is not implemented at {}", strategy->span.toString()));
  if (std::holds_alternative<ir::Strategy::End>(strategy->value)) return std::string("end");
  if (std::holds_alternative<ir::Strategy::Continue>(strategy->value)) return std::string("continue");
  if (auto p = std::get_if<ir::Strategy::FlowRef>(&strategy->value))
  {
    const auto port = symbolName(p->flow);
    env.requiresPorts.insert(std::format("iaction {}", port));
    env.calls.push_back({CallUse::Kind::Flow, port, InvalidSymbol, p->flow, 0, strategy->span});
    return port;
  }
  if (auto p = std::get_if<ir::Strategy::TaskCall>(&strategy->value))
  {
    auto call = emitCall(p->call, env, false); if (!call.IsSuccess()) return call;
    std::string endpoint = call.Value();
    // Emit emitter handlers first, matching the ordering used by the old compiler.
    for (const auto& h : p->handlers)
    {
      if (h->kind != ir::HandlerKind::Emitter && h->kind != ir::HandlerKind::EmitterContinue) continue;
      env.previousCall = endpoint;
      auto wrapped = emitHandler(h, env, flowFile); if (!wrapped.IsSuccess()) return wrapped;
      endpoint = wrapped.Value();
    }
    for (const auto& h : p->handlers)
    {
      if (h->kind == ir::HandlerKind::Emitter || h->kind == ir::HandlerKind::EmitterContinue) continue;
      env.previousCall = endpoint;
      auto wrapped = emitHandler(h, env, flowFile); if (!wrapped.IsSuccess()) return wrapped;
      endpoint = wrapped.Value();
    }
    return endpoint;
  }

  return Result<std::string>::Failed("Unknown strategy in Dezyne emitter");
}

Result<std::string> DezyneEmitter::emitHandler(const ir::PHandler& handler, FlowContext& env, const std::string& flowFile)
{
  if (!handler) return Result<std::string>::Failed("Invalid strategy handler");
  if (handler->kind == ir::HandlerKind::Abort || handler->kind == ir::HandlerKind::Error)
  {
    const bool abort = handler->kind == ir::HandlerKind::Abort;
    const auto id = abort ? env.abortHandler++ : env.errorHandler++;
    const auto prefix = abort ? "ah" : "fh";
    env.includes.insert(abort ? "abort_handler.dzn" : "error_handler.dzn");
    env.definitions.push_back({std::format("{} {}{}", abort ? "cabort_handler" : "cerror_handler", prefix, id), std::format("{}{}", prefix, id), handler->span});
    auto body = emitStrategy(handler->body, env, flowFile); if (!body.IsSuccess()) return body;
    env.core.push_back(std::format("{}{}.action <=> {}", prefix, id, env.previousCall));
    env.core.push_back(std::format("{}{}.handler <=> {}", prefix, id, body.Value()));
    return std::format("{}{}.api", prefix, id);
  }

  if (!handler->emitter) return Result<std::string>::Failed("Emitter handler has no emitter call");
  const auto id = env.signalHandler++;
  const bool cont = handler->kind == ir::HandlerKind::EmitterContinue;
  env.includes.insert(cont ? "signal_continue.dzn" : "signal_handler.dzn");
  env.definitions.push_back({std::format("{} sh{}", cont ? "csignal_continue" : "csignal_handler", id), std::format("sh{}", id), handler->span});
  auto signal = emitCall(*handler->emitter, env, true); if (!signal.IsSuccess()) return signal;
  auto body = emitStrategy(handler->body, env, flowFile); if (!body.IsSuccess()) return body;
  env.core.push_back(std::format("sh{}.signal <=> {}", id, signal.Value()));
  env.core.push_back(std::format("sh{}.action <=> {}", id, env.previousCall));
  env.core.push_back(std::format("sh{}.handler <=> {}", id, body.Value()));
  return std::format("sh{}.api", id);
}

Result<std::string> DezyneEmitter::emitCall(const ir::Call& call, FlowContext& env, bool signal)
{
  if (call.kind == ir::CallKind::CapabilityTrigger)
  {
    if (signal) return Result<std::string>::Failed("Capability trigger cannot be used as a signal");
    const auto ordinal = increment(env.triggerCounts, call.receiver);
    const auto local = std::format("{}_{}", symbolName(call.receiver), ordinal);
    env.requiresPorts.insert(std::format("iaction {}", local));
    env.calls.push_back({CallUse::Kind::Trigger, local, call.receiver, call.target, ordinal, call.span});
    return local;
  }

  const auto local = std::format("{}_{}", symbolName(call.receiver), eventName(call.target));
  env.requiresPorts.insert(std::format("{} {}", signal ? "isignal" : "iaction", local));
  env.calls.push_back({signal ? CallUse::Kind::Signal : CallUse::Kind::Action,
                       local, call.receiver, call.target, 0, call.span});
  return local;
}

Result<std::string> DezyneEmitter::emitExpression(const ir::PExpression& expr) const
{
  if (!expr) return Result<std::string>::Failed("Invalid expression");
  if (auto p = std::get_if<ir::Expression::Literal>(&expr->value)) return p->text;
  if (auto p = std::get_if<ir::Expression::Reference>(&expr->value)) return symbolName(p->symbol);
  if (auto p = std::get_if<ir::Expression::CallExpr>(&expr->value)) return eventName(p->call.target);
  if (auto p = std::get_if<ir::Expression::Unary>(&expr->value))
  {
    auto v = emitExpression(p->value); if (!v.IsSuccess()) return v;
    return p->op + v.Value();
  }
  if (auto p = std::get_if<ir::Expression::Binary>(&expr->value))
  {
    auto a = emitExpression(p->lhs); if (!a.IsSuccess()) return a;
    auto b = emitExpression(p->rhs); if (!b.IsSuccess()) return b;
    return std::format("{} {} {}", a.Value(), p->op, b.Value());
  }
  return Result<std::string>::Failed("Unknown expression");
}

VoidResult DezyneEmitter::createSequenceComponent(std::uint32_t instances)
{
  if (mOptions->dryRun) return VoidResult{};
  const auto filename = std::format("{}/sequence{}.dzn", mOptions->outputDir, instances);
  if (std::filesystem::exists(filename)) return VoidResult{};
  std::ofstream file(filename);
  if (!file.is_open()) return VoidResult::Failed("Failed to open: " + filename);
  recordComponent(std::format("csequence{}", instances), filename, std::nullopt, std::nullopt, true);

  file << "import types.dzn;\nimport iaction.dzn;\n\n";
  file << std::format("component csequence{} {{\n", instances);
  file << "  provides iaction api;\n";
  for (std::uint32_t i = 0; i < instances; ++i) file << std::format("  requires iaction action{};\n", i);
  file << "\n  behaviour {\n";
  file << "    enum State { Idle, ";
  for (std::uint32_t i = 0; i < instances; ++i) file << std::format("Action{}, ", i);
  file << "Error };\n    State state = State.Idle;\n\n";
  file << "    [state.Idle] {\n      on api.trigger(): {\n        Result ret = action0.trigger();\n        if (ret.Success) {\n          state = State.Action0;\n        } else if (ret.Done) {\n";
  createSequenceDoneRecursion(true, 1, instances, file, "          ");
  file << "        } else {\n          state = State.Error;\n        }\n        reply(ret);\n      }\n    }\n\n";
  for (std::uint32_t i = 0; i < instances; ++i)
  {
    file << std::format("    [state.Action{}] {{\n", i);
    file << std::format("      on action{}.success(): {{\n", i);
    if (i + 1 == instances) file << "        api.success();\n        state = State.Idle;\n";
    else
    {
      file << std::format("        Result ret = action{}.trigger();\n", i + 1);
      file << "        if (ret.Success) {\n" << std::format("          state = State.Action{};\n", i + 1) << "        } else if (ret.Done) {\n";
      createSequenceDoneRecursion(false, i + 2, instances, file, "          ");
      file << "        } else {\n          api.failure();\n          state = State.Error;\n        }\n";
    }
    file << "      }\n\n" << std::format("      on action{}.failure(): {{\n", i)
         << "        api.failure();\n        state = State.Error;\n      }\n\n"
         << "      on api.abort(): {\n" << std::format("        Result ret = action{}.abort();\n", i)
         << "        if (ret.Success) state = State.Idle;\n        else if (ret.Failure) state = State.Error;\n        reply(ret);\n      }\n    }\n\n";
  }
  file << "    [state.Error] {\n      on api.abort(): { reply(Result.Success); }\n      on api.reset(): { state = State.Idle; reply(Result.Success); }\n    }\n  }\n}\n";
  file.close(); mGeneratedFiles.push_back(filename); return VoidResult{};
}

VoidResult DezyneEmitter::createActionArbiterComponent(std::uint32_t instances)
{
  if (mOptions->dryRun) return VoidResult{};
  const auto filename = std::format("{}/action_arbiter{}.dzn", mOptions->outputDir, instances);
  if (std::filesystem::exists(filename)) return VoidResult{};
  std::ofstream file(filename);
  if (!file.is_open()) return VoidResult::Failed("Failed to open: " + filename);
  recordComponent(std::format("caction_arbiter{}", instances), filename, std::nullopt, std::nullopt, true);

  file << "import types.dzn;\nimport iaction.dzn;\n\n";
  file << std::format("component caction_arbiter{} {{\n", instances);
  for (std::uint32_t i = 0; i < instances; ++i) file << std::format("  provides iaction client{};\n", i);
  file << "  requires iaction resource;\n\n  behaviour {\n";
  file << "    enum Owner { None";
  for (std::uint32_t i = 0; i < instances; ++i) file << std::format(", C{}", i);
  file << " };\n    Owner owner = Owner.None;\n\n    [owner.None] {\n";
  for (std::uint32_t i = 0; i < instances; ++i)
  {
    file << std::format("      on client{}.trigger(): {{ Result r = resource.trigger(); if (!r.Done) owner = Owner.C{}; reply(r); }}\n", i, i);
    file << std::format("      on client{}.abort(): {{ reply(Result.Success); }}\n", i);
    file << std::format("      on client{}.reset(): {{ reply(Result.Success); }}\n", i);
  }
  file << "    }\n    on resource.success(): { defer() {";
  for (std::uint32_t i = 0; i < instances; ++i) file << std::format(" if (owner.C{}) client{}.success();", i, i);
  file << " owner = Owner.None; } }\n    on resource.failure(): { defer() {";
  for (std::uint32_t i = 0; i < instances; ++i) file << std::format(" if (owner.C{}) client{}.failure();", i, i);
  file << " owner = Owner.None; } }\n";
  for (std::uint32_t i = 0; i < instances; ++i)
  {
    file << std::format("    [owner.C{}] {{\n", i);
    file << std::format("      on client{}.abort(): {{ Result r = resource.abort(); if (r.Success) owner = Owner.None; reply(r); }}\n", i);
    file << std::format("      on client{}.reset(): {{ Result r = resource.reset(); if (r.Success) owner = Owner.None; reply(r); }}\n", i);
    for (std::uint32_t j = 0; j < instances; ++j) if (j != i)
    {
      file << std::format("      on client{}.trigger(): {{ reply(Result.Running); }}\n", j);
      file << std::format("      on client{}.abort(): {{ reply(Result.Success); }}\n", j);
      file << std::format("      on client{}.reset(): {{ reply(Result.Failure); }}\n", j);
    }
    file << "    }\n";
  }
  file << "  }\n}\n";
  file.close(); mGeneratedFiles.push_back(filename); return VoidResult{};
}

void DezyneEmitter::createSequenceDoneRecursion(bool fromIdle, std::uint32_t start, std::uint32_t instances,
                                                std::ofstream& file, const std::string& indent)
{
  if (start >= instances)
  {
    if (!fromIdle) file << indent << "api.success();\n";
    file << indent << "state = State.Idle;\n";
    return;
  }
  file << std::format("{}ret = action{}.trigger();\n", indent, start);
  file << indent << "if (ret.Success) {\n" << std::format("{}  state = State.Action{};\n", indent, start)
       << indent << "} else if (ret.Done) {\n";
  createSequenceDoneRecursion(fromIdle, start + 1, instances, file, indent + "  ");
  file << indent << "} else {\n";
  if (!fromIdle) file << indent << "  api.failure();\n";
  file << indent << "  state = State.Error;\n" << indent << "}\n";
}

std::string DezyneEmitter::symbolName(SymbolId id) const
{
  const auto* symbol = mSymbols ? mSymbols->get(id) : nullptr;
  return symbol ? symbol->name : std::string("<unknown>");
}

std::string DezyneEmitter::componentTypeName(SymbolId id) const
{
  return componentName(symbolName(id));
}

std::string DezyneEmitter::triggerEventName(SymbolId capability) const
{
  auto it = mTriggerEvents.find(capability);
  return it == mTriggerEvents.end() ? "trigger" : it->second;
}

std::string DezyneEmitter::eventName(SymbolId event) const
{
  return symbolName(event);
}

std::string DezyneEmitter::toFilename(const std::string& name)
{
  std::string result = name;
  for (auto& c : result) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return result;
}

std::string DezyneEmitter::componentName(const std::string& name) { return "c" + toFilename(name); }
std::string DezyneEmitter::flowName(const std::string& name) { return "f" + toFilename(name); }

dezyne::SymbolId DezyneEmitter::recordComponent(const std::string& name, const std::string& file,
                                                 std::optional<SymbolId> source, std::optional<Span> span,
                                                 bool helper)
{
  return mModel.symbols.add(helper ? dezyne::SymbolKind::HelperComponent : dezyne::SymbolKind::Component,
                            name, name, file, dezyne::InvalidSymbol, source, span);
}

void DezyneEmitter::recordPort(dezyne::SymbolId component, const std::string& name, const std::string& file,
                               std::optional<SymbolId> source, std::optional<Span> span)
{
  const auto* parent = mModel.symbols.get(component);
  mModel.symbols.add(dezyne::SymbolKind::Port, name,
                     parent ? parent->qualifiedName + "." + name : name,
                     file, component, source, span);
}

void DezyneEmitter::recordInstance(dezyne::SymbolId component, const std::string& name, const std::string& file,
                                   std::optional<SymbolId> source, std::optional<Span> span)
{
  const auto* parent = mModel.symbols.get(component);
  mModel.symbols.add(dezyne::SymbolKind::Instance, name,
                     parent ? parent->qualifiedName + "." + name : name,
                     file, component, source, span);
}

void DezyneEmitter::recordConnection(dezyne::SymbolId component, const Connection& connection, const std::string& file)
{
  const auto name = connection.lhsInstance == "api"
      ? std::format("api<=>{}.{}", connection.rhsInstance, connection.rhsPort)
      : std::format("{}.{}<=>{}.{}", connection.lhsInstance, connection.lhsPort, connection.rhsInstance, connection.rhsPort);
  mModel.symbols.add(dezyne::SymbolKind::Connection, name, name, file, component, std::nullopt, connection.span);
}

}  // namespace koda
