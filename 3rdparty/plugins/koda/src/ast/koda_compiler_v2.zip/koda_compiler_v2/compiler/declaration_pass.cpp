#include "declaration_pass.h"

#include <format>

namespace koda
{
namespace
{
VoidResult asVoid(const Result<SymbolId>& result)
{
  if (!result.IsSuccess())
    return VoidResult::Failed(result.ErrorMessage());
  return VoidResult{};
}
}

VoidResult DeclarationPass::run(const System& system)
{
  mSymbols.clear();

  // First register every top-level component. This is what makes forward references legal.
  for (const auto& component : system.components)
  {
    const auto kind = component->kind == Component::Kind::Task ? SymbolKind::Task : SymbolKind::Capability;
    auto result = mSymbols.declare(kind, component->name, Type::Unknown(), component->span);
    if (!result.IsSuccess())
      return VoidResult::Failed(result.ErrorMessage());
  }

  // Then populate each component scope.
  for (const auto& component : system.components)
  {
    auto result = declareComponent(component);
    if (!result.IsSuccess())
      return result;
  }

  return VoidResult{};
}

VoidResult DeclarationPass::declareComponent(const PComponent& component)
{
  const auto ownerOpt = mSymbols.component(component->name);
  if (!ownerOpt)
    return VoidResult::Failed(std::format("Internal compiler error: component '{}' was not registered", component->name));
  const auto owner = *ownerOpt;

  for (const auto& arg : component->args)
  {
    const auto type = mSymbols.resolveType(arg->b).value_or(Type::Unknown());
    auto result = mSymbols.declare(SymbolKind::Argument, arg->a, type, arg->span, owner);
    if (!result.IsSuccess())
      return VoidResult::Failed(result.ErrorMessage());
  }

  for (const auto& statement : component->statements)
  {
    auto result = declareStatement(statement, owner);
    if (!result.IsSuccess())
      return result;
  }

  return VoidResult{};
}

VoidResult DeclarationPass::declareStatement(const PStatement& statement, SymbolId owner)
{
  if (auto block = std::get_if<PVarsBlock>(&statement->node); block && *block)
  {
    for (const auto& var : (*block)->vars)
    {
      const auto type = mSymbols.resolveType(var->varType).value_or(Type::Unknown());
      auto result = mSymbols.declare(SymbolKind::Variable, var->name, type, var->span, owner);
      if (!result.IsSuccess())
        return VoidResult::Failed(result.ErrorMessage());
    }
  }
  else if (auto block = std::get_if<PStrategyBlock>(&statement->node); block && *block)
  {
    for (const auto& flow : (*block)->flows)
    {
      auto result = mSymbols.declare(SymbolKind::Flow, flow->name, Type::Void(), flow->span, owner);
      if (!result.IsSuccess())
        return VoidResult::Failed(result.ErrorMessage());
    }
  }
  else if (auto ros = std::get_if<PRosDef>(&statement->node); ros && *ros)
  {
    return declareRosDef(*ros, owner);
  }
  else if (auto action = std::get_if<PActionDef>(&statement->node); action && *action)
  {
    for (const auto& ros : (*action)->rosDefs)
    {
      auto result = declareRosDef(ros, owner);
      if (!result.IsSuccess())
        return result;
    }
  }

  return VoidResult{};
}

VoidResult DeclarationPass::declareRosDef(const PRosDef& ros, SymbolId owner)
{
  if (!ros || !ros->def)
    return VoidResult::Failed("Invalid ROS/event declaration");

  const auto eventType = mSymbols.resolveType(ros->def->typeName).value_or(Type::Custom(ros->def->typeName));
  auto result = mSymbols.declare(SymbolKind::Event, ros->def->name, eventType, ros->def->span, owner);
  return asVoid(result);
}

}  // namespace koda
