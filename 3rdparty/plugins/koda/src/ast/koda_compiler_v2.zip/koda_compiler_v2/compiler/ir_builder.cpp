#include "ir_builder.h"

#include <format>

namespace koda
{
Result<ir::Program> IRBuilder::build(const System& system) const
{
  ir::Program program;
  for (const auto& component : system.components)
  {
    auto built = buildComponent(component);
    if (!built.IsSuccess()) return Result<ir::Program>::Failed(built.ErrorMessage());
    program.components.push_back(built.Value());
  }
  return program;
}

Result<ir::Component> IRBuilder::buildComponent(const PComponent& component) const
{
  const auto ownerOpt = mSymbols.component(component->name);
  if (!ownerOpt) return Result<ir::Component>::Failed(std::format("Unknown component '{}'", component->name));
  const auto owner = *ownerOpt;

  ir::Component out;
  out.symbol = owner;
  out.kind = component->kind == Component::Kind::Task ? ir::ComponentKind::Task : ir::ComponentKind::Capability;
  out.name = component->name;
  out.span = component->span;

  for (const auto& arg : component->args)
  {
    const auto id = mSymbols.lookupChild(owner, arg->a);
    const auto* symbol = id ? mSymbols.get(*id) : nullptr;
    ir::Argument a;
    a.symbol = id.value_or(InvalidSymbol);
    a.name = arg->a;
    a.type = symbol ? symbol->type : Type::Unknown();
    a.mode = arg->kind == Argument::Kind::Req ? ir::ArgumentMode::Requires
           : arg->kind == Argument::Kind::Pro ? ir::ArgumentMode::Provides
                                               : ir::ArgumentMode::Plain;
    a.span = arg->span;
    out.arguments.push_back(std::move(a));
  }

  for (const auto& statement : component->statements)
  {
    if (auto vars = std::get_if<PVarsBlock>(&statement->node); vars && *vars)
    {
      for (const auto& var : (*vars)->vars)
      {
        const auto id = mSymbols.lookupChild(owner, var->name);
        const auto* symbol = id ? mSymbols.get(*id) : nullptr;
        auto initial = buildExpr(var->init, owner); if (!initial.IsSuccess()) return Result<ir::Component>::Failed(initial.ErrorMessage());
        auto fallback = buildExpr(var->fallback, owner); if (!fallback.IsSuccess()) return Result<ir::Component>::Failed(fallback.ErrorMessage());
        out.variables.push_back(ir::Variable{id.value_or(InvalidSymbol), var->name, symbol ? symbol->type : Type::Unknown(), initial.Value(), fallback.Value(), var->span});
      }
    }
    else if (auto flows = std::get_if<PStrategyBlock>(&statement->node); flows && *flows)
    {
      for (const auto& flow : (*flows)->flows)
      {
        auto built = buildFlow(flow, owner);
        if (!built.IsSuccess()) return Result<ir::Component>::Failed(built.ErrorMessage());
        out.flows.push_back(built.Value());
      }
    }
    else if (auto ros = std::get_if<PRosDef>(&statement->node); ros && *ros)
    {
      appendRosDef(*ros, owner, out);
    }
    else if (auto action = std::get_if<PActionDef>(&statement->node); action && *action)
    {
      out.title = (*action)->label1;
      out.message = (*action)->label2;
      for (const auto& ros : (*action)->rosDefs) appendRosDef(ros, owner, out);
    }
  }

  return out;
}

void IRBuilder::appendRosDef(const PRosDef& ros, SymbolId owner, ir::Component& out) const
{
  if (!ros || !ros->def) return;
  const auto id = mSymbols.lookupChild(owner, ros->def->name);
  const auto* symbol = id ? mSymbols.get(*id) : nullptr;

  ir::Event event;
  event.symbol = id.value_or(InvalidSymbol);
  event.name = ros->def->name;
  event.type = symbol ? symbol->type : Type::Unknown();
  event.span = ros->def->span;
  switch (ros->kind)
  {
    case RosDef::Kind::Trigger: event.kind = ir::EventKind::Trigger; break;
    case RosDef::Kind::Return: event.kind = ir::EventKind::Return; break;
    case RosDef::Kind::Abort: event.kind = ir::EventKind::Abort; break;
    case RosDef::Kind::Error: event.kind = ir::EventKind::Error; break;
    case RosDef::Kind::In: event.kind = ir::EventKind::In; break;
    case RosDef::Kind::Out: event.kind = ir::EventKind::Out; break;
    default: break;
  }
  for (const auto& arg : ros->def->args)
  {
    event.arguments.push_back(ir::Argument{InvalidSymbol, arg->a,
        mSymbols.resolveType(arg->b).value_or(Type::Unknown()),
        arg->kind == Argument::Kind::Req ? ir::ArgumentMode::Requires
        : arg->kind == Argument::Kind::Pro ? ir::ArgumentMode::Provides
                                           : ir::ArgumentMode::Plain,
        arg->span});
  }
  out.events.push_back(std::move(event));
}

Result<ir::Flow> IRBuilder::buildFlow(const PFlow& flow, SymbolId owner) const
{
  auto strategy = buildStrategy(flow->strategy, owner);
  if (!strategy.IsSuccess()) return Result<ir::Flow>::Failed(strategy.ErrorMessage());
  return ir::Flow{mSymbols.lookupChild(owner, flow->name).value_or(InvalidSymbol), flow->name, flow->tags, strategy.Value(), flow->span};
}

Result<ir::PStrategy> IRBuilder::buildStrategy(const PStrategy& strategy, SymbolId owner) const
{
  if (!strategy) return Result<ir::PStrategy>::Failed("Invalid strategy");
  auto out = std::make_shared<ir::Strategy>();
  out->span = strategy->span;

  if (auto p = std::get_if<PSeq>(&strategy->v); p && *p)
  {
    ir::Strategy::Sequence x;
    for (const auto& child : (*p)->alts) { auto b = buildStrategy(child, owner); if (!b.IsSuccess()) return b; x.items.push_back(b.Value()); }
    out->value = std::move(x);
  }
  else if (auto p = std::get_if<PJoin>(&strategy->v); p && *p)
  {
    ir::Strategy::Join x;
    for (const auto& child : (*p)->alts) { auto b = buildStrategy(child, owner); if (!b.IsSuccess()) return b; x.items.push_back(b.Value()); }
    out->value = std::move(x);
  }
  else if (auto p = std::get_if<PEither>(&strategy->v); p && *p)
  {
    ir::Strategy::Either x;
    for (const auto& child : (*p)->alts) { auto b = buildStrategy(child, owner); if (!b.IsSuccess()) return b; x.items.push_back(b.Value()); }
    out->value = std::move(x);
  }
  else if (auto p = std::get_if<PLet>(&strategy->v); p && *p)
  {
    auto call = buildCall((*p)->call, owner); if (!call.IsSuccess()) return Result<ir::PStrategy>::Failed(call.ErrorMessage());
    out->value = ir::Strategy::Let{mSymbols.lookupLocal((*p)->name, owner).value_or(InvalidSymbol), call.Value()};
  }
  else if (auto p = std::get_if<PWithin>(&strategy->v); p && *p)
  {
    auto a = buildStrategy((*p)->a, owner); if (!a.IsSuccess()) return a;
    auto b = buildStrategy((*p)->b, owner); if (!b.IsSuccess()) return b;
    ir::Strategy::Within x{(*p)->seconds, a.Value(), b.Value(), {}};
    for (const auto& h : (*p)->handlers) { auto bh = buildHandler(h, owner); if (!bh.IsSuccess()) return Result<ir::PStrategy>::Failed(bh.ErrorMessage()); x.handlers.push_back(bh.Value()); }
    out->value = std::move(x);
  }
  else if (auto p = std::get_if<PIfElse>(&strategy->v); p && *p)
  {
    auto c = buildExpr((*p)->cond, owner); if (!c.IsSuccess()) return Result<ir::PStrategy>::Failed(c.ErrorMessage());
    auto a = buildStrategy((*p)->a, owner); if (!a.IsSuccess()) return a;
    ir::PStrategy b;
    if ((*p)->b) { auto bb = buildStrategy((*p)->b, owner); if (!bb.IsSuccess()) return bb; b = bb.Value(); }
    out->value = ir::Strategy::IfElse{c.Value(), a.Value(), b};
  }
  else if (auto p = std::get_if<PRepeat>(&strategy->v); p && *p)
  {
    auto body = buildStrategy((*p)->a, owner); if (!body.IsSuccess()) return body;
    ir::Strategy::Repeat x{(*p)->seconds, (*p)->iterations, body.Value(), {}};
    for (const auto& h : (*p)->handlers) { auto bh = buildHandler(h, owner); if (!bh.IsSuccess()) return Result<ir::PStrategy>::Failed(bh.ErrorMessage()); x.handlers.push_back(bh.Value()); }
    out->value = std::move(x);
  }
  else if (auto p = std::get_if<PGuard>(&strategy->v); p && *p)
  {
    auto c = buildExpr((*p)->cond, owner); if (!c.IsSuccess()) return Result<ir::PStrategy>::Failed(c.ErrorMessage());
    out->value = ir::Strategy::Guard{c.Value()};
  }
  else if (std::holds_alternative<PEnd>(strategy->v)) out->value = ir::Strategy::End{};
  else if (std::holds_alternative<PContinue>(strategy->v)) out->value = ir::Strategy::Continue{};
  else if (std::holds_alternative<PRef>(strategy->v))
  {
    auto it = mSemantics.flowRefs.find(strategy.get());
    if (it == mSemantics.flowRefs.end()) return Result<ir::PStrategy>::Failed("Unresolved flow reference");
    out->value = ir::Strategy::FlowRef{it->second};
  }
  else if (auto p = std::get_if<PTaskCall>(&strategy->v); p && *p)
  {
    auto call = buildCall((*p)->call, owner); if (!call.IsSuccess()) return Result<ir::PStrategy>::Failed(call.ErrorMessage());
    ir::Strategy::TaskCall x{call.Value(), {}};
    for (const auto& h : (*p)->handlers) { auto bh = buildHandler(h, owner); if (!bh.IsSuccess()) return Result<ir::PStrategy>::Failed(bh.ErrorMessage()); x.handlers.push_back(bh.Value()); }
    out->value = std::move(x);
  }
  else if (auto p = std::get_if<PParen>(&strategy->v); p && *p)
  {
    return buildStrategy((*p)->a, owner);
  }
  else return Result<ir::PStrategy>::Failed("Unsupported strategy node");

  return out;
}

Result<ir::PHandler> IRBuilder::buildHandler(const PStrategyHandler& handler, SymbolId owner) const
{
  auto out = std::make_shared<ir::Handler>();
  out->span = handler->span;
  switch (handler->kind)
  {
    case StrategyHandler::Kind::OnError: out->kind = ir::HandlerKind::Error; break;
    case StrategyHandler::Kind::OnAbort: out->kind = ir::HandlerKind::Abort; break;
    case StrategyHandler::Kind::OnEmitter: out->kind = ir::HandlerKind::Emitter; break;
    case StrategyHandler::Kind::OnEmitterContinue: out->kind = ir::HandlerKind::EmitterContinue; break;
    default: break;
  }
  if (handler->emitter)
  {
    auto c = buildCall(handler->emitter, owner); if (!c.IsSuccess()) return Result<ir::PHandler>::Failed(c.ErrorMessage());
    out->emitter = c.Value();
  }
  if (handler->body)
  {
    auto b = buildStrategy(handler->body, owner); if (!b.IsSuccess()) return Result<ir::PHandler>::Failed(b.ErrorMessage());
    out->body = b.Value();
  }
  return out;
}

Result<ir::Call> IRBuilder::buildCall(const PEventCall& call, SymbolId owner) const
{
  auto it = mSemantics.calls.find(call.get());
  if (it == mSemantics.calls.end()) return Result<ir::Call>::Failed(std::format("Unresolved call at {}", call->span.toString()));
  ir::Call out;
  out.kind = it->second.kind == ResolvedCallKind::CapabilityTrigger ? ir::CallKind::CapabilityTrigger : ir::CallKind::Event;
  out.receiver = it->second.receiver;
  out.target = it->second.target;
  out.span = call->span;
  for (const auto& arg : call->args)
  {
    auto e = buildExpr(arg, owner); if (!e.IsSuccess()) return Result<ir::Call>::Failed(e.ErrorMessage());
    out.arguments.push_back(e.Value());
  }
  return out;
}

Result<ir::PExpression> IRBuilder::buildExpr(const PExpr& expr, SymbolId owner) const
{
  if (!expr) return Result<ir::PExpression>::Failed("Invalid expression");
  auto out = std::make_shared<ir::Expression>();
  out->span = expr->span;
  auto typeIt = mSemantics.expressionTypes.find(expr.get());
  out->type = typeIt == mSemantics.expressionTypes.end() ? Type::Unknown() : typeIt->second;

  if (auto p = std::get_if<PStr>(&expr->v); p && *p) out->value = ir::Expression::Literal{(*p)->value, Type::String()};
  else if (auto p = std::get_if<PInt>(&expr->v); p && *p) out->value = ir::Expression::Literal{std::to_string((*p)->value), Type::Int()};
  else if (auto p = std::get_if<PFloat>(&expr->v); p && *p) out->value = ir::Expression::Literal{std::to_string((*p)->value), Type::Float()};
  else if (auto p = std::get_if<PId>(&expr->v); p && *p)
  {
    auto id = mSymbols.lookup((*p)->value, owner);
    if (!id) return Result<ir::PExpression>::Failed(std::format("Unresolved identifier '{}'", (*p)->value));
    out->value = ir::Expression::Reference{*id};
  }
  else if (auto p = std::get_if<PCall>(&expr->v); p && *p)
  {
    auto c = buildCall((*p)->value, owner); if (!c.IsSuccess()) return Result<ir::PExpression>::Failed(c.ErrorMessage());
    out->value = ir::Expression::CallExpr{c.Value()};
  }
  else if (auto p = std::get_if<PNeg>(&expr->v); p && *p)
  {
    auto v = buildExpr((*p)->value, owner); if (!v.IsSuccess()) return v;
    out->value = ir::Expression::Unary{"-", v.Value()};
  }
  else if (auto p = std::get_if<PNot>(&expr->v); p && *p)
  {
    auto v = buildExpr((*p)->value, owner); if (!v.IsSuccess()) return v;
    out->value = ir::Expression::Unary{"!", v.Value()};
  }
  else if (auto p = std::get_if<PBinOp>(&expr->v); p && *p)
  {
    auto a = buildExpr((*p)->a, owner); if (!a.IsSuccess()) return a;
    ir::PExpression b;
    if ((*p)->b) { auto bb = buildExpr((*p)->b, owner); if (!bb.IsSuccess()) return bb; b = bb.Value(); }
    using K = Expr::BinOp::Kind;
    std::string op;
    switch ((*p)->operation)
    {
      case K::Equal: op = "="; break; case K::NotEqual: op = "!="; break;
      case K::GreaterThan: op = ">"; break; case K::GreaterEqual: op = ">="; break;
      case K::LessThan: op = "<"; break; case K::LessEqual: op = "<="; break;
      case K::Addition: op = "+"; break; case K::Subtraction: op = "-"; break;
      case K::Multiplication: op = "*"; break; case K::Division: op = "/"; break;
      case K::Disjunction: op = "||"; break; case K::Conjunction: op = "&&"; break;
      case K::Negation: op = "!"; break; case K::Unary: op = "-"; break;
      default: op = "?"; break;
    }
    if (!b) out->value = ir::Expression::Unary{op, a.Value()};
    else out->value = ir::Expression::Binary{op, a.Value(), b};
  }
  else if (auto p = std::get_if<PEParen>(&expr->v); p && *p) return buildExpr((*p)->value, owner);
  else return Result<ir::PExpression>::Failed("Unsupported expression node");

  return out;
}

}  // namespace koda
