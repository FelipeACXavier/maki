#pragma once

#include <cstdint>
#include <limits>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include "ast.h"
#include "symbol.h"

namespace koda::dezyne
{
using SymbolId = std::uint32_t;
inline constexpr SymbolId InvalidSymbol = std::numeric_limits<SymbolId>::max();

enum class SymbolKind
{
  Component,
  Port,
  Instance,
  Connection,
  HelperComponent
};

struct Symbol
{
  SymbolId id = InvalidSymbol;
  SymbolKind kind = SymbolKind::Component;
  std::string name;
  std::string qualifiedName;
  std::string file;
  SymbolId parent = InvalidSymbol;
  std::optional<koda::SymbolId> sourceSymbol;
  std::optional<Span> sourceSpan;
};

class SymbolTable
{
public:
  void clear();
  SymbolId add(SymbolKind kind,
               std::string name,
               std::string qualifiedName,
               std::string file,
               SymbolId parent = InvalidSymbol,
               std::optional<koda::SymbolId> sourceSymbol = std::nullopt,
               std::optional<Span> sourceSpan = std::nullopt);

  const Symbol* get(SymbolId id) const;
  std::vector<const Symbol*> fromKodaSymbol(koda::SymbolId source) const;
  std::vector<const Symbol*> fromSpan(const Span& span) const;

private:
  std::vector<Symbol> mSymbols;
  std::unordered_multimap<koda::SymbolId, SymbolId> mBySource;
};

struct Model
{
  SymbolTable symbols;
};

}  // namespace koda::dezyne
