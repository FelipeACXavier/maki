#pragma once

#include <deque>
#include <fstream>
#include <map>
#include <set>
#include <string>
#include <vector>

#include "dezyne_model.h"
#include "emitter.h"

namespace koda
{
class DezyneEmitter final : public Emitter
{
public:
  std::string id() const override { return "dezyne"; }
  VoidResult emit(const ir::Program& program,
                  const SymbolRegistry& symbols,
                  const CompilerOptions& options) override;
  const std::vector<std::string>& generatedFiles() const override { return mGeneratedFiles; }

  const dezyne::Model& model() const { return mModel; }

private:
  struct CallUse
  {
    enum class Kind { Trigger, Action, Signal, Flow } kind = Kind::Action;
    std::string localPort;
    SymbolId receiver = InvalidSymbol;
    SymbolId target = InvalidSymbol;
    std::uint32_t ordinal = 0;
    Span span;
  };

  struct FlowResult
  {
    std::string endpoint;
    std::vector<CallUse> calls;
    std::vector<std::string> alarms;
  };

  struct Definition
  {
    std::string text;
    std::string instance;
    Span span;
  };

  struct FlowContext
  {
    std::uint32_t sequence = 0;
    std::uint32_t join = 0;
    std::uint32_t repeat = 0;
    std::uint32_t within = 0;
    std::uint32_t every = 0;
    std::uint32_t abortHandler = 0;
    std::uint32_t errorHandler = 0;
    std::uint32_t signalHandler = 0;
    std::uint32_t alarm = 0;

    std::string previousCall;
    std::set<std::string> includes;
    std::set<std::string> requiresPorts;
    std::deque<Definition> definitions;
    std::deque<std::string> core;
    std::map<SymbolId, std::uint32_t> triggerCounts;
    std::vector<CallUse> calls;
    std::vector<std::string> alarms;
  };

  struct Connection
  {
    std::string lhsInstance;
    std::string lhsPort;
    std::string rhsInstance;
    std::string rhsPort;
    Span span;
  };

  VoidResult precomputeTriggerCounts(const ir::Program& program);
  void countStrategyTriggers(const ir::PStrategy& strategy);
  void countHandlerTriggers(const ir::PHandler& handler);
  void countCallTrigger(const ir::Call& call);

  VoidResult emitCapability(const ir::Component& capability);
  VoidResult emitTask(const ir::Component& task);
  Result<FlowResult> emitFlow(const ir::Component& task, const ir::Flow& flow);

  Result<std::string> emitStrategy(const ir::PStrategy& strategy, FlowContext& env, const std::string& flowFile);
  Result<std::string> emitHandler(const ir::PHandler& handler, FlowContext& env, const std::string& flowFile);
  Result<std::string> emitCall(const ir::Call& call, FlowContext& env, bool signal);
  Result<std::string> emitExpression(const ir::PExpression& expr) const;

  VoidResult createSequenceComponent(std::uint32_t instances);
  VoidResult createActionArbiterComponent(std::uint32_t instances);
  void createSequenceDoneRecursion(bool fromIdle, std::uint32_t start, std::uint32_t instances,
                                   std::ofstream& file, const std::string& indent);

  std::string symbolName(SymbolId id) const;
  std::string componentTypeName(SymbolId id) const;
  std::string triggerEventName(SymbolId capability) const;
  std::string eventName(SymbolId event) const;

  static std::string toFilename(const std::string& name);
  static std::string componentName(const std::string& name);
  static std::string flowName(const std::string& name);

  dezyne::SymbolId recordComponent(const std::string& name, const std::string& file,
                                   std::optional<SymbolId> source, std::optional<Span> span,
                                   bool helper = false);
  void recordPort(dezyne::SymbolId component, const std::string& name, const std::string& file,
                  std::optional<SymbolId> source, std::optional<Span> span);
  void recordInstance(dezyne::SymbolId component, const std::string& name, const std::string& file,
                      std::optional<SymbolId> source, std::optional<Span> span);
  void recordConnection(dezyne::SymbolId component, const Connection& connection, const std::string& file);

  const SymbolRegistry* mSymbols = nullptr;
  const CompilerOptions* mOptions = nullptr;
  dezyne::Model mModel;
  std::vector<std::string> mGeneratedFiles;
  std::map<SymbolId, std::uint32_t> mCapabilityTriggerCounts;
  std::map<SymbolId, std::string> mTriggerEvents;
  std::map<SymbolId, FlowResult> mFlowResults;
};

}  // namespace koda
