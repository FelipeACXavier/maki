#include "dezyne_model.h"

namespace koda::dezyne
{
namespace
{
bool sameSpan(const Span& a, const Span& b)
{
  return a.lineStart == b.lineStart && a.colStart == b.colStart &&
         a.lineEnd == b.lineEnd && a.colEnd == b.colEnd;
}
}

void SymbolTable::clear()
{
  mSymbols.clear();
  mBySource.clear();
}

SymbolId SymbolTable::add(SymbolKind kind,
                          std::string name,
                          std::string qualifiedName,
                          std::string file,
                          SymbolId parent,
                          std::optional<koda::SymbolId> sourceSymbol,
                          std::optional<Span> sourceSpan)
{
  const auto id = static_cast<SymbolId>(mSymbols.size());
  mSymbols.push_back(Symbol{id, kind, std::move(name), std::move(qualifiedName), std::move(file), parent, sourceSymbol, sourceSpan});
  if (sourceSymbol) mBySource.emplace(*sourceSymbol, id);
  return id;
}

const Symbol* SymbolTable::get(SymbolId id) const
{
  return id < mSymbols.size() ? &mSymbols[id] : nullptr;
}

std::vector<const Symbol*> SymbolTable::fromKodaSymbol(koda::SymbolId source) const
{
  std::vector<const Symbol*> result;
  auto [first, last] = mBySource.equal_range(source);
  for (auto it = first; it != last; ++it)
    if (const auto* symbol = get(it->second)) result.push_back(symbol);
  return result;
}

std::vector<const Symbol*> SymbolTable::fromSpan(const Span& span) const
{
  std::vector<const Symbol*> result;
  for (const auto& symbol : mSymbols)
    if (symbol.sourceSpan && sameSpan(*symbol.sourceSpan, span)) result.push_back(&symbol);
  return result;
}

}  // namespace koda::dezyne
