# Koda compiler v2 integration

Pipeline:

    ANTLR -> AST -> DeclarationPass/SymbolRegistry -> SemanticAnalyzer
          -> IRBuilder -> Koda IR -> Emitter(s)

The default Compiler constructor installs a DezyneEmitter, preserving the old
`parse(options); generate();` shape.

## Additional backend provenance files

The requested file list is extended with:

- `compiler/emitters/dezyne_model.h`
- `compiler/emitters/dezyne_model.cpp`

`dezyne::SymbolTable` records generated components, ports, instances and
connections. Every entry can carry both a frontend Koda SymbolId and/or a Koda
Span. This intentionally supports one-to-many mappings.

## Current backend parity

The frontend and IR represent all current grammar strategy nodes. The Dezyne
backend emits the constructs that the previous compiler implemented:
sequence, join, within, repeat/every, flow references, capability/event calls,
and handlers.

The previous compiler had empty implementations for `either`, `let`, `if/else`
and `guard`. The new DezyneEmitter reports an explicit error for these rather
than silently returning an empty endpoint.

## Existing plugins

Existing KodaPlugin instances still receive the AST for compatibility. A later
plugin-v2 interface can consume the SemanticModel or Koda IR.
