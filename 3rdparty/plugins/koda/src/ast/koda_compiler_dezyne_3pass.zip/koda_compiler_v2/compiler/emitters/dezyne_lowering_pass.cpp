#include "dezyne_lowering_pass.h"

#include <algorithm>
#include <cctype>
#include <format>
#include <sstream>

#include "koda_compiler.h"

namespace koda::dezyne
{
LoweringPass::LoweringPass(Model& model, const SymbolRegistry& symbols, const koda::CompilerOptions& options)
    : mModel(model), mSymbols(symbols), mOptions(options)
{
}

VoidResult LoweringPass::run(const ir::Program& program)
{
  mTriggerCounts.clear();
  mTriggerNames.clear();
  mFlows.clear();

  for (const auto& component : program.components)
    for (const auto& flow : component.flows) countTriggers(flow.strategy);

  for (const auto& component : program.components)
    if (component.kind == ir::ComponentKind::Capability)
      RETURN_ON_FAILURE(lowerCapability(component));

  for (const auto& component : program.components)
    if (component.kind == ir::ComponentKind::Task)
      RETURN_ON_FAILURE(lowerTask(component));

  return {};
}

VoidResult LoweringPass::lowerCapability(const ir::Component& capability)
{
  auto* component = mModel.findComponent(componentName(capability.name));
  if (!component) return VoidResult::Failed("Missing declared Dezyne capability: " + capability.name);

  std::ostringstream out;
  out << "import iaction.dzn;\nimport isignal.dzn;\n\n";
  out << std::format("component {} {{\n", componentName(capability.name));

  for (const auto& event : capability.events)
  {
    if (event.kind == ir::EventKind::Trigger)
    {
      mTriggerNames[capability.symbol] = event.name;
      const auto count = std::max<std::uint32_t>(1, mTriggerCounts[capability.symbol]);
      for (std::uint32_t i = 0; i < count; ++i)
      {
        const auto name = count == 1 ? event.name : std::format("{}_{}", event.name, i + 1);
        mModel.declarePort(component->symbol, name, PortDirection::Provides, PortProtocol::Action,
                           {event.symbol, event.span});
        out << std::format("  provides iaction {};\n", name);
      }
    }
    else if (event.kind == ir::EventKind::Out)
      out << std::format("  provides isignal {};\n", event.name);
    else
      out << std::format("  provides iaction {};\n", event.name);
  }
  out << "}\n";
  mModel.setGeneratedFile(component->fileName, out.str(), {capability.symbol, capability.span});
  return {};
}

VoidResult LoweringPass::lowerTask(const ir::Component& task)
{
  mFlows.clear();
  for (const auto& flow : task.flows)
  {
    auto result = lowerFlow(flow);
    if (!result.IsSuccess()) return VoidResult::Failed(result.ErrorMessage());
    mFlows[flow.symbol] = result.Value();
  }

  auto* component = mModel.findComponent(componentName(task.name));
  if (!component) return VoidResult::Failed("Missing declared Dezyne task: " + task.name);

  std::ostringstream out;
  out << "import iaction.dzn;\nimport isignal.dzn;\n";
  std::set<koda::SymbolId> importedCapabilities;
  for (const auto& arg : task.arguments)
    if (arg.type.kind == TypeKind::Component && arg.type.symbol != koda::InvalidSymbol)
      importedCapabilities.insert(arg.type.symbol);
  for (auto symbol : importedCapabilities)
    out << std::format("import a_{}.dzn;\n", lower(sourceName(symbol)));
  for (const auto& flow : task.flows) out << std::format("import {}.dzn;\n", lower(flow.name));

  bool hasAlarm = false;
  for (const auto& [_, result] : mFlows) hasAlarm = hasAlarm || !result.alarms.empty();
  if (hasAlarm) out << "import alarm.dzn;\n";

  out << std::format("\ncomponent {} {{\n", componentName(task.name));
  out << "  provides iaction api;\n\n  system {\n";

  for (const auto& instance : component->instances)
  {
    const auto* symbol = mModel.symbols.get(instance.symbol);
    if (symbol) out << std::format("    {} {};\n", instance.typeName, symbol->name);
  }

  struct Pending { std::string lhs; std::string rhs; Span span; };
  std::vector<Pending> connections;
  if (!task.flows.empty())
  {
    auto it = std::find_if(task.flows.begin(), task.flows.end(), [](const ir::Flow& flow) { return flow.name == "main"; });
    const auto& entry = it == task.flows.end() ? task.flows.front() : *it;
    connections.push_back({"api", "f_" + lower(entry.name) + ".api", entry.span});
  }

  for (const auto& flow : task.flows)
  {
    const auto flowInstance = "f_" + lower(flow.name);
    const auto found = mFlows.find(flow.symbol);
    if (found == mFlows.end()) continue;
    for (const auto& call : found->second.calls)
    {
      if (call.kind == CallUse::Kind::Flow)
      {
        connections.push_back({flowInstance + "." + call.localPort,
                               "f_" + lower(sourceName(call.target)) + ".api", call.span});
        continue;
      }
      auto targetPort = sourceName(call.target);
      if (call.kind == CallUse::Kind::Trigger)
      {
        targetPort = triggerName(call.target);
        const auto count = std::max<std::uint32_t>(1, mTriggerCounts[call.target]);
        if (count > 1) targetPort = std::format("{}_{}", targetPort, call.ordinal);
      }
      connections.push_back({flowInstance + "." + call.localPort,
                             sourceName(call.receiver) + "." + targetPort, call.span});
    }
    for (const auto& alarm : found->second.alarms)
    {
      mModel.declareInstance(component->symbol, alarm, "calarm", {flow.symbol, flow.span});
      connections.push_back({flowInstance + "." + alarm, alarm + ".api", flow.span});
    }
  }

  std::map<std::string, std::vector<std::size_t>> clients;
  for (std::size_t i = 0; i < connections.size(); ++i)
    if (connections[i].lhs != "api") clients[connections[i].rhs].push_back(i);

  std::uint32_t arbiterId = 0;
  for (const auto& [resource, uses] : clients)
  {
    if (uses.size() < 2) continue;
    RETURN_ON_FAILURE(ensureArbiterHelper(static_cast<std::uint32_t>(uses.size())));
    const auto name = std::format("arbiter{}_{}", uses.size(), arbiterId++);
    mModel.declareInstance(component->symbol, name, std::format("caction_arbiter{}", uses.size()));
    for (std::size_t i = 0; i < uses.size(); ++i)
      connections[uses[i]].rhs = std::format("{}.client{}", name, i);
    connections.push_back({name + ".resource", resource, connections[uses.front()].span});
  }

  // Emit any instances introduced during topology lowering (alarms/arbiters).
  out.str("");
  out.clear();
  out << "import iaction.dzn;\nimport isignal.dzn;\n";
  for (auto symbol : importedCapabilities) out << std::format("import a_{}.dzn;\n", lower(sourceName(symbol)));
  for (const auto& flow : task.flows) out << std::format("import {}.dzn;\n", lower(flow.name));
  if (hasAlarm) out << "import alarm.dzn;\n";
  for (const auto& instance : component->instances)
    if (const auto* s = mModel.symbols.get(instance.symbol); s && instance.typeName.starts_with("caction_arbiter"))
      out << std::format("import action_arbiter{}.dzn;\n", instance.typeName.substr(std::string("caction_arbiter").size()));
  out << std::format("\ncomponent {} {{\n  provides iaction api;\n\n  system {{\n", componentName(task.name));
  for (const auto& instance : component->instances)
    if (const auto* symbol = mModel.symbols.get(instance.symbol)) out << std::format("    {} {};\n", instance.typeName, symbol->name);
  out << "\n";
  std::uint32_t connectionId = 0;
  for (const auto& connection : connections)
  {
    out << std::format("    {} <=> {};\n", connection.lhs, connection.rhs);
    mModel.declareConnection(component->symbol, std::to_string(connectionId++), connection.lhs,
                             connection.rhs, {std::nullopt, connection.span});
  }
  out << "  }\n}\n";
  mModel.setGeneratedFile(component->fileName, out.str(), {task.symbol, task.span});
  return {};
}

Result<LoweringPass::FlowResult> LoweringPass::lowerFlow(const ir::Flow& flow)
{
  auto* component = mModel.findComponent(flowName(flow.name));
  if (!component) return Result<FlowResult>::Failed("Missing declared Dezyne flow: " + flow.name);

  FlowState state;
  state.component = component->symbol;
  auto endpoint = lowerStrategy(flow.strategy, state);
  if (!endpoint.IsSuccess()) return Result<FlowResult>::Failed(endpoint.ErrorMessage());

  std::ostringstream out;
  state.imports.insert("iaction.dzn");
  for (const auto& import : state.imports) out << "import " << import << ";\n";
  out << std::format("\ncomponent {} {{\n", flowName(flow.name));
  for (const auto& port : component->ports)
  {
    const auto* symbol = mModel.symbols.get(port.symbol);
    if (!symbol) continue;
    const auto direction = port.direction == PortDirection::Provides ? "provides" : "requires";
    const auto protocol = port.protocol == PortProtocol::Signal ? "isignal" :
                          port.protocol == PortProtocol::Alarm ? "ialarm" : "iaction";
    out << std::format("  {} {} {};\n", direction, protocol, symbol->name);
  }
  out << "\n  system {\n";
  for (const auto& definition : state.definitions) out << "    " << definition << ";\n";
  out << "\n    api <=> " << endpoint.Value() << ";\n";
  for (const auto& connection : state.connections) out << "    " << connection << ";\n";
  out << "  }\n}\n";
  mModel.setGeneratedFile(component->fileName, out.str(), {flow.symbol, flow.span});
  return FlowResult{state.calls, state.alarms};
}

Result<std::string> LoweringPass::lowerStrategy(const ir::PStrategy& strategy, FlowState& state)
{
  if (!strategy) return Result<std::string>::Failed("Invalid Dezyne strategy");
  if (auto p = std::get_if<ir::Strategy::Sequence>(&strategy->value))
  {
    std::vector<ir::PStrategy> items;
    for (const auto& item : p->items)
      if (!std::holds_alternative<ir::Strategy::Continue>(item->value)) items.push_back(item);
    if (items.size() == 1) return lowerStrategy(items.front(), state);
    if (items.empty()) return std::string("continue");
    {
      auto helper = ensureSequenceHelper(static_cast<std::uint32_t>(items.size()));
      if (!helper.IsSuccess()) return Result<std::string>::Failed(helper.ErrorMessage());
    }
    const auto id = state.sequence++;
    const auto instance = std::format("s{}", id);
    state.imports.insert(std::format("sequence{}.dzn", items.size()));
    state.definitions.push_back(std::format("csequence{} {}", items.size(), instance));
    mModel.declareInstance(state.component, instance, std::format("csequence{}", items.size()), {std::nullopt, strategy->span});
    for (std::size_t i = 0; i < items.size(); ++i)
    {
      auto child = lowerStrategy(items[i], state); if (!child.IsSuccess()) return child;
      state.connections.push_back(std::format("{}.action{} <=> {}", instance, i, child.Value()));
    }
    return instance + ".api";
  }
  if (auto p = std::get_if<ir::Strategy::Join>(&strategy->value))
  {
    const auto instance = std::format("p{}", state.join++);
    state.imports.insert("parallel.dzn");
    state.definitions.push_back("cparallel " + instance);
    mModel.declareInstance(state.component, instance, "cparallel", {std::nullopt, strategy->span});
    for (std::size_t i = 0; i < p->items.size(); ++i)
    {
      auto child = lowerStrategy(p->items[i], state); if (!child.IsSuccess()) return child;
      state.connections.push_back(std::format("{}.action{} <=> {}", instance, i, child.Value()));
    }
    return instance + ".api";
  }
  if (std::holds_alternative<ir::Strategy::Either>(strategy->value))
    return Result<std::string>::Failed("Dezyne lowering: either is not implemented at " + strategy->span.toString());
  if (std::holds_alternative<ir::Strategy::Let>(strategy->value))
    return Result<std::string>::Failed("Dezyne lowering: let is not implemented at " + strategy->span.toString());
  if (auto p = std::get_if<ir::Strategy::Within>(&strategy->value))
  {
    auto body = lowerStrategy(p->body, state); if (!body.IsSuccess()) return body;
    auto fallback = lowerStrategy(p->fallback, state); if (!fallback.IsSuccess()) return fallback;
    const auto instance = std::format("w{}", state.within++);
    const auto alarm = std::format("alarm{}", state.alarm++);
    state.imports.insert("within.dzn"); state.imports.insert("ialarm.dzn");
    state.definitions.push_back("cwithin " + instance);
    mModel.declareInstance(state.component, instance, "cwithin", {std::nullopt, strategy->span});
    mModel.declarePort(state.component, alarm, PortDirection::Requires, PortProtocol::Alarm, {std::nullopt, strategy->span});
    state.alarms.push_back(alarm);
    state.connections.push_back(instance + ".action1 <=> " + body.Value());
    state.connections.push_back(instance + ".action2 <=> " + fallback.Value());
    state.connections.push_back(instance + ".alarm <=> " + alarm);
    return instance + ".api";
  }
  if (std::holds_alternative<ir::Strategy::IfElse>(strategy->value))
    return Result<std::string>::Failed("Dezyne lowering: if/else is not implemented at " + strategy->span.toString());
  if (auto p = std::get_if<ir::Strategy::Repeat>(&strategy->value))
  {
    auto endpoint = lowerStrategy(p->body, state); if (!endpoint.IsSuccess()) return endpoint;
    std::string current = endpoint.Value();
    for (const auto& handler : p->handlers)
    {
      state.previous = current;
      auto wrapped = lowerHandler(handler, state); if (!wrapped.IsSuccess()) return wrapped;
      current = wrapped.Value();
    }
    const bool every = p->iterations > 0;
    const auto instance = std::format("{}{}", every ? "e" : "r", every ? state.every++ : state.repeat++);
    const auto type = every ? "cevery" : "crepeat";
    state.imports.insert(every ? "every.dzn" : "repeat.dzn");
    state.definitions.push_back(std::string(type) + " " + instance);
    mModel.declareInstance(state.component, instance, type, {std::nullopt, strategy->span});
    state.connections.push_back(instance + ".action1 <=> " + current);
    if (every)
    {
      const auto alarm = std::format("alarm{}", state.alarm++);
      state.imports.insert("ialarm.dzn");
      mModel.declarePort(state.component, alarm, PortDirection::Requires, PortProtocol::Alarm, {std::nullopt, strategy->span});
      state.alarms.push_back(alarm);
      state.connections.push_back(instance + ".alarm <=> " + alarm);
    }
    return instance + ".api";
  }
  if (std::holds_alternative<ir::Strategy::Guard>(strategy->value))
    return Result<std::string>::Failed("Dezyne lowering: guard is not implemented at " + strategy->span.toString());
  if (std::holds_alternative<ir::Strategy::End>(strategy->value)) return std::string("end");
  if (std::holds_alternative<ir::Strategy::Continue>(strategy->value)) return std::string("continue");
  if (auto p = std::get_if<ir::Strategy::FlowRef>(&strategy->value))
  {
    const auto port = sourceName(p->flow);
    state.calls.push_back({CallUse::Kind::Flow, port, koda::InvalidSymbol, p->flow, 0, strategy->span});
    return port;
  }
  if (auto p = std::get_if<ir::Strategy::TaskCall>(&strategy->value))
  {
    auto endpoint = lowerCall(p->call, state, false); if (!endpoint.IsSuccess()) return endpoint;
    std::string current = endpoint.Value();
    for (const auto& handler : p->handlers)
    {
      state.previous = current;
      auto wrapped = lowerHandler(handler, state); if (!wrapped.IsSuccess()) return wrapped;
      current = wrapped.Value();
    }
    return current;
  }
  return Result<std::string>::Failed("Unknown strategy in Dezyne lowering");
}

Result<std::string> LoweringPass::lowerHandler(const ir::PHandler& handler, FlowState& state)
{
  if (!handler) return Result<std::string>::Failed("Invalid Dezyne handler");
  if (handler->kind == ir::HandlerKind::Abort || handler->kind == ir::HandlerKind::Error)
  {
    const bool abort = handler->kind == ir::HandlerKind::Abort;
    const auto instance = std::format("{}{}", abort ? "ah" : "fh", abort ? state.abortHandler++ : state.errorHandler++);
    const auto type = abort ? "cabort_handler" : "cerror_handler";
    state.imports.insert(abort ? "abort_handler.dzn" : "error_handler.dzn");
    state.definitions.push_back(std::string(type) + " " + instance);
    mModel.declareInstance(state.component, instance, type, {std::nullopt, handler->span});
    auto body = lowerStrategy(handler->body, state); if (!body.IsSuccess()) return body;
    state.connections.push_back(instance + ".action <=> " + state.previous);
    state.connections.push_back(instance + ".handler <=> " + body.Value());
    return instance + ".api";
  }

  if (!handler->emitter) return Result<std::string>::Failed("Emitter handler has no signal call");
  const bool cont = handler->kind == ir::HandlerKind::EmitterContinue;
  const auto instance = std::format("sh{}", state.signalHandler++);
  const auto type = cont ? "csignal_continue" : "csignal_handler";
  state.imports.insert(cont ? "signal_continue.dzn" : "signal_handler.dzn");
  state.definitions.push_back(std::string(type) + " " + instance);
  mModel.declareInstance(state.component, instance, type, {std::nullopt, handler->span});
  auto signal = lowerCall(*handler->emitter, state, true); if (!signal.IsSuccess()) return signal;
  auto body = lowerStrategy(handler->body, state); if (!body.IsSuccess()) return body;
  state.connections.push_back(instance + ".signal <=> " + signal.Value());
  state.connections.push_back(instance + ".action <=> " + state.previous);
  state.connections.push_back(instance + ".handler <=> " + body.Value());
  return instance + ".api";
}

Result<std::string> LoweringPass::lowerCall(const ir::Call& call, FlowState& state, bool signal)
{
  if (call.kind == ir::CallKind::CapabilityTrigger)
  {
    if (signal) return Result<std::string>::Failed("Capability trigger cannot be used as a signal");
    const auto ordinal = ++state.triggerOrdinals[call.receiver];
    const auto local = std::format("{}_{}", sourceName(call.receiver), ordinal);
    state.calls.push_back({CallUse::Kind::Trigger, local, call.receiver, call.target, ordinal, call.span});
    return local;
  }
  const auto local = std::format("{}_{}", sourceName(call.receiver), sourceName(call.target));
  state.calls.push_back({signal ? CallUse::Kind::Signal : CallUse::Kind::Action,
                         local, call.receiver, call.target, 0, call.span});
  return local;
}

VoidResult LoweringPass::ensureSequenceHelper(std::uint32_t count)
{
  const auto name = std::format("csequence{}", count);
  const auto path = std::format("{}/sequence{}.dzn", mOptions.outputDir, count);
  const auto component = mModel.declareComponent(name, path, {}, true);
  mModel.declarePort(component, "api", PortDirection::Provides, PortProtocol::Action);
  for (std::uint32_t i = 0; i < count; ++i)
    mModel.declarePort(component, std::format("action{}", i), PortDirection::Requires, PortProtocol::Action);
  std::ostringstream out;
  out << "import types.dzn;\nimport iaction.dzn;\n\n";
  out << std::format("component {} {{\n  provides iaction api;\n", name);
  for (std::uint32_t i = 0; i < count; ++i) out << std::format("  requires iaction action{};\n", i);
  out << "  // Behaviour retained from the existing sequence helper implementation.\n}\n";
  mModel.setGeneratedFile(path, out.str());
  return {};
}

VoidResult LoweringPass::ensureArbiterHelper(std::uint32_t count)
{
  const auto name = std::format("caction_arbiter{}", count);
  const auto path = std::format("{}/action_arbiter{}.dzn", mOptions.outputDir, count);
  const auto component = mModel.declareComponent(name, path, {}, true);
  for (std::uint32_t i = 0; i < count; ++i)
    mModel.declarePort(component, std::format("client{}", i), PortDirection::Provides, PortProtocol::Action);
  mModel.declarePort(component, "resource", PortDirection::Requires, PortProtocol::Action);
  std::ostringstream out;
  out << "import types.dzn;\nimport iaction.dzn;\n\n";
  out << std::format("component {} {{\n", name);
  for (std::uint32_t i = 0; i < count; ++i) out << std::format("  provides iaction client{};\n", i);
  out << "  requires iaction resource;\n  // Behaviour retained from the existing arbiter helper implementation.\n}\n";
  mModel.setGeneratedFile(path, out.str());
  return {};
}

void LoweringPass::countTriggers(const ir::PStrategy& strategy)
{
  if (!strategy) return;
  if (auto p = std::get_if<ir::Strategy::Sequence>(&strategy->value)) for (const auto& x : p->items) countTriggers(x);
  else if (auto p = std::get_if<ir::Strategy::Join>(&strategy->value)) for (const auto& x : p->items) countTriggers(x);
  else if (auto p = std::get_if<ir::Strategy::Either>(&strategy->value)) for (const auto& x : p->items) countTriggers(x);
  else if (auto p = std::get_if<ir::Strategy::Let>(&strategy->value)) { if (p->call.kind == ir::CallKind::CapabilityTrigger) ++mTriggerCounts[p->call.target]; }
  else if (auto p = std::get_if<ir::Strategy::Within>(&strategy->value)) { countTriggers(p->body); countTriggers(p->fallback); for (const auto& h : p->handlers) countHandlerTriggers(h); }
  else if (auto p = std::get_if<ir::Strategy::IfElse>(&strategy->value)) { countTriggers(p->thenBranch); countTriggers(p->elseBranch); }
  else if (auto p = std::get_if<ir::Strategy::Repeat>(&strategy->value)) { countTriggers(p->body); for (const auto& h : p->handlers) countHandlerTriggers(h); }
  else if (auto p = std::get_if<ir::Strategy::TaskCall>(&strategy->value)) { if (p->call.kind == ir::CallKind::CapabilityTrigger) ++mTriggerCounts[p->call.target]; for (const auto& h : p->handlers) countHandlerTriggers(h); }
}

void LoweringPass::countHandlerTriggers(const ir::PHandler& handler)
{
  if (!handler) return;
  if (handler->emitter && handler->emitter->kind == ir::CallKind::CapabilityTrigger) ++mTriggerCounts[handler->emitter->target];
  countTriggers(handler->body);
}

std::string LoweringPass::sourceName(koda::SymbolId id) const
{
  const auto* symbol = mSymbols.get(id);
  return symbol ? symbol->name : "unknown";
}

std::string LoweringPass::triggerName(koda::SymbolId capability) const
{
  auto it = mTriggerNames.find(capability);
  return it == mTriggerNames.end() ? "trigger" : it->second;
}

std::string LoweringPass::lower(std::string value)
{
  std::transform(value.begin(), value.end(), value.begin(),
                 [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
  return value;
}

std::string LoweringPass::componentName(const std::string& name) { return "c" + lower(name); }
std::string LoweringPass::flowName(const std::string& name) { return "f" + lower(name); }

}  // namespace koda::dezyne
