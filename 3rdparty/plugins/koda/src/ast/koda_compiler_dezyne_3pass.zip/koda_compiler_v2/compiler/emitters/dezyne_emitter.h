#pragma once

#include <string>
#include <vector>

#include "dezyne_model.h"
#include "dezyne_writer.h"
#include "emitter.h"

namespace koda
{
class DezyneEmitter final : public Emitter
{
public:
  std::string id() const override { return "dezyne"; }

  VoidResult generate(const ir::Program& program,
                      const SymbolRegistry& symbols,
                      const CompilerOptions& options) override;

  const std::vector<std::string>& generatedFiles() const override { return mGeneratedFiles; }
  const dezyne::Model& model() const { return mModel; }

private:
  dezyne::Model mModel;
  dezyne::Writer mWriter;
  std::vector<std::string> mGeneratedFiles;
};

}  // namespace koda
