# Dezyne three-pass backend

The Dezyne backend now runs as:

1. `dezyne::DeclarationPass`: declares IR-derived Dezyne components, ports, and task instances.
2. `dezyne::LoweringPass`: creates helper instances, alarms, arbiters, and connections; fills generated-file contents in the model.
3. `dezyne::Writer`: performs filesystem output only.

`DezyneEmitter` is only the orchestrator. Its `model()` accessor exposes the complete backend model and symbol/provenance table after generation.

## Important

The generated sequence and arbiter helper bodies in this package are placeholders marked with comments. Copy the full behaviour bodies from your previous `createSequenceComponent` and `createActionArbiterComponent` implementations into `LoweringPass::ensureSequenceHelper` and `LoweringPass::ensureArbiterHelper` before relying on those helpers at runtime.

The `Emitter` method is named `generate`, not `emit`, to avoid Qt's `emit` macro.
